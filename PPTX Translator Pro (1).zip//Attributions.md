This Figma Make file includes components from [shadcn/ui](https://ui.shadcn.com/) used under [MIT license](https://github.com/shadcn-ui/ui/blob/main/LICENSE.md).

This Figma Make file includes photos from [Unsplash](https://unsplash.com) used under [license](https://unsplash.com/license).

This work incorporates elements from [Master No-Code Web Design with Framer - Figma Template](https://www.figma.com/community/file/1349410423606748407), a community file created by Meng To and licensed under [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/).